/* Fire-S Manual Sprint 203A - Data Load Checker Hotfix
   Changed-files-only module. Loads before app.js and protects JSON data loading. */
(function () {
  'use strict';

  if (window.fireSDataLoadCheckerApplied) return;
  window.fireSDataLoadCheckerApplied = true;

  const JSON_FILE_PATTERN = /(?:^|\/)(checklists|rules|requirements|occupancies|templates)\.json(?:\?|$)/i;
  const originalFetch = window.fetch ? window.fetch.bind(window) : null;

  function getUrl(input) {
    if (typeof input === 'string') return input;
    if (input && typeof input.url === 'string') return input.url;
    return '';
  }

  function looksLikeJavaScript(text) {
    const sample = String(text || '').trim().slice(0, 120);
    return /^(let|const|var|function|class|import|export|\/\*)\b/.test(sample);
  }

  function looksLikeHtml(text) {
    const sample = String(text || '').trim().slice(0, 120).toLowerCase();
    return sample.startsWith('<!doctype') || sample.startsWith('<html') || sample.startsWith('<head') || sample.startsWith('<body') || sample.includes('<script');
  }

  function showDataLoadError(fileName, detail) {
    const text = `App data failed to load\n${fileName} ${detail}`;

    function render() {
      const home = document.getElementById('homeSection') || document.body;
      let panel = document.getElementById('fireSDataLoadErrorPanel');

      if (!panel) {
        panel = document.createElement('div');
        panel.id = 'fireSDataLoadErrorPanel';
        panel.style.cssText = [
          'margin:16px',
          'padding:14px',
          'border:2px solid #b71c1c',
          'border-radius:10px',
          'background:#fff3f3',
          'color:#4a0000',
          'font-family:system-ui,Segoe UI,Arial,sans-serif',
          'white-space:pre-wrap',
          'z-index:99999',
          'position:relative'
        ].join(';');
        home.prepend(panel);
      }

      panel.textContent = `${text}\n\nFix: replace the listed JSON file on the server with the correct .json file, then press Ctrl + F5.`;
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', render, { once: true });
    } else {
      render();
    }
  }

  if (!originalFetch) return;

  window.fetch = async function fireSCheckedFetch(input, init) {
    const url = getUrl(input);
    const response = await originalFetch(input, init);

    if (!JSON_FILE_PATTERN.test(url)) {
      return response;
    }

    const clone = response.clone();
    const fileName = (url.split('/').pop() || url).split('?')[0];

    try {
      const text = await clone.text();

      if (looksLikeJavaScript(text)) {
        const message = 'returned JavaScript instead of JSON. The wrong file was uploaded or cached.';
        showDataLoadError(fileName, message);
        throw new Error(`${fileName} ${message}`);
      }

      if (looksLikeHtml(text)) {
        const message = 'returned HTML instead of JSON. Check the file path and upload location.';
        showDataLoadError(fileName, message);
        throw new Error(`${fileName} ${message}`);
      }

      JSON.parse(text);
    } catch (error) {
      if (error && /instead of JSON/.test(error.message || '')) {
        throw error;
      }

      const message = `is not valid JSON. ${error && error.message ? error.message : ''}`.trim();
      showDataLoadError(fileName, message);
      throw new Error(`${fileName} ${message}`);
    }

    return response;
  };
})();
