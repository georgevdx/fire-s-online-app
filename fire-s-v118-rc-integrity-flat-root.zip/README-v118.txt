Fire-S v118 RC Integrity Patch

Upload these files directly to GitHub root.
Fixes: delete current inspection only; active context lock; Scheduled Today; Last 5 Completed; mobile CSS/cache refresh.
