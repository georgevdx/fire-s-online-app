Fire-S GitHub Ready Upload

This package excludes large nested sprint ZIP files, .bak backup files, and log files.
Upload/commit these source files to GitHub instead of the full working ZIP.

Important:
- Do not upload old sprint ZIPs into the repo.
- Keep generated release ZIPs outside the repository, or attach them to GitHub Releases.
- Use .gitignore to prevent large files from being committed again.
