Fire-S v123 RC Core Context Safety

Purpose:
- Replaces unsafe Delete Inspection with safe current-inspection clearing.
- Premises record is kept.
- Building Passport / premises details are kept.
- inspectionHistory is kept.
- Cloud delete is not used by Delete Inspection.
- Backup import clears legacy deleted registers.
- Local workspace does not upload local-user to Supabase.

Upload these files to GitHub root:
- index.html
- app.js
- styles.css
- service-worker.js
- README-FIRE-S-V123.txt

Open:
https://georgevdx.github.io/fireye-online-app/?v=123

Test first:
1. Import backup and confirm expected inspection count.
2. Open an existing premises with history.
3. Click Delete Inspection.
4. Confirm the warning says current inspection only.
5. Confirm premises remains and history count remains.
