/* Fire-S Sprint 111.1 - Analytics Consolidation
   Keeps operational pages clean by moving Inspection History, Inspection Comparison,
   and Trend Analytics into the dedicated Analytics workspace. */
(function () {
  'use strict';

  const VERSION = '111.1-analytics-consolidation';
  let installed = false;
  let wrapping = false;

  function esc(value) {
    return String(value ?? '').replace(/[&<>'"]/g, ch => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
    }[ch]));
  }

  function projects() {
    try {
      if (typeof getProjects === 'function') return getProjects() || [];
      return JSON.parse(localStorage.getItem('fireyeProjects') || '[]');
    } catch (_) {
      return [];
    }
  }

  function currentProject() {
    try {
      const id = typeof currentProjectId !== 'undefined' ? currentProjectId : null;
      return projects().find(p => String(p?.id) === String(id)) || null;
    } catch (_) {
      return null;
    }
  }

  function currentProjectIdValue() {
    const project = currentProject();
    return project?.id || (typeof currentProjectId !== 'undefined' ? currentProjectId : null);
  }

  function removeEmptyOperationalPanels() {
    const analytics = document.getElementById('analyticsSection');
    ['sprint109HistoryPanel', 'sprint1092ComparisonPanel', 'sprint1093TrendPanel'].forEach(id => {
      const node = document.getElementById(id);
      if (node && analytics && !analytics.contains(node)) {
        node.remove();
      }
    });
  }

  function createConsolidationShell() {
    const container = document.getElementById('analyticsContent');
    if (!container) return null;

    let shell = document.getElementById('analyticsConsolidatedSections');
    if (shell && container.contains(shell)) return shell;

    shell = document.createElement('div');
    shell.id = 'analyticsConsolidatedSections';
    shell.className = 'analytics-consolidated-sections';
    shell.innerHTML = `
      <div class="analytics-subnav" aria-label="Analytics sections">
        <a href="#analyticsExecutiveOverview">Executive Overview</a>
        <a href="#analyticsHistoryWorkspace">Inspection History</a>
        <a href="#analyticsComparisonWorkspace">Inspection Comparison</a>
        <a href="#analyticsTrendWorkspace">Trend Analytics</a>
      </div>

      <section class="analytics-panel analytics-management-panel" id="analyticsHistoryWorkspace">
        <div class="analytics-panel-heading">
          <div>
            <h3>Inspection History</h3>
            <p>Previous inspections are managed here, away from the operational inspection page.</p>
          </div>
        </div>
        <div id="analyticsHistoryHost" class="analytics-module-host"></div>
      </section>

      <section class="analytics-panel analytics-management-panel" id="analyticsComparisonWorkspace">
        <div class="analytics-panel-heading">
          <div>
            <h3>Inspection Comparison</h3>
            <p>Compare the current inspection with previous inspection records.</p>
          </div>
        </div>
        <div id="analyticsComparisonHost" class="analytics-module-host"></div>
      </section>

      <section class="analytics-panel analytics-management-panel" id="analyticsTrendWorkspace">
        <div class="analytics-panel-heading">
          <div>
            <h3>Trend Analytics</h3>
            <p>Compliance, action and repeated-item trends live in the Analytics workspace only.</p>
          </div>
        </div>
        <div id="analyticsTrendHost" class="analytics-module-host"></div>
      </section>
    `;

    container.appendChild(shell);
    return shell;
  }

  function ensureExecutiveAnchor() {
    const content = document.getElementById('analyticsContent');
    if (!content) return;
    const firstPanel = content.querySelector('.analytics-tiles, .analytics-panel, .analytics-grid-two');
    if (firstPanel && !document.getElementById('analyticsExecutiveOverview')) {
      const anchor = document.createElement('span');
      anchor.id = 'analyticsExecutiveOverview';
      anchor.className = 'analytics-anchor';
      firstPanel.parentNode.insertBefore(anchor, firstPanel);
    }
  }

  function movePanelToHost(panelId, hostId) {
    const host = document.getElementById(hostId);
    if (!host) return false;
    const panel = document.getElementById(panelId);
    if (!panel) return false;
    host.innerHTML = '';
    host.appendChild(panel);
    panel.classList.add('analytics-contained-module');
    panel.style.display = '';
    return true;
  }

  function renderModuleIntoAnalytics(moduleName, renderFn, panelId, hostId, projectId) {
    if (!projectId || typeof renderFn !== 'function') return;
    try {
      wrapping = true;
      renderFn(projectId);
    } catch (error) {
      console.warn(`Fire-S ${moduleName} could not render inside Analytics`, error);
    } finally {
      wrapping = false;
    }
    movePanelToHost(panelId, hostId);
  }

  function renderConsolidatedAnalytics() {
    const section = document.getElementById('analyticsSection');
    if (!section || section.style.display === 'none') {
      removeEmptyOperationalPanels();
      return;
    }

    const projectId = currentProjectIdValue();
    createConsolidationShell();
    ensureExecutiveAnchor();

    if (!projectId) {
      ['analyticsHistoryHost', 'analyticsComparisonHost', 'analyticsTrendHost'].forEach(id => {
        const host = document.getElementById(id);
        if (host) host.innerHTML = '<div class="analytics-empty">Open an inspection first.</div>';
      });
      return;
    }

    const historyApi = window.FireSInspectionHistory109;
    const comparisonApi = window.FireSComparison1092;
    const trendApi = window.FireSTrends1093;

    renderModuleIntoAnalytics('Inspection History', historyApi?.renderHistoryPanel, 'sprint109HistoryPanel', 'analyticsHistoryHost', projectId);
    renderModuleIntoAnalytics('Inspection Comparison', comparisonApi?.render, 'sprint1092ComparisonPanel', 'analyticsComparisonHost', projectId);
    renderModuleIntoAnalytics('Trend Analytics', trendApi?.render, 'sprint1093TrendPanel', 'analyticsTrendHost', projectId);

    removeEmptyOperationalPanels();
  }

  function wrapModuleRenderers() {
    const historyApi = window.FireSInspectionHistory109;
    if (historyApi && typeof historyApi.renderHistoryPanel === 'function' && !historyApi.renderHistoryPanel.__analyticsWrapped) {
      const original = historyApi.renderHistoryPanel;
      const wrapped = function (projectId) {
        const result = original.apply(this, arguments);
        if (!wrapping) setTimeout(() => movePanelToHost('sprint109HistoryPanel', 'analyticsHistoryHost') || removeEmptyOperationalPanels(), 40);
        return result;
      };
      wrapped.__analyticsWrapped = true;
      wrapped.__original = original;
      historyApi.renderHistoryPanel = wrapped;
    }

    const comparisonApi = window.FireSComparison1092;
    if (comparisonApi && typeof comparisonApi.render === 'function' && !comparisonApi.render.__analyticsWrapped) {
      const original = comparisonApi.render;
      const wrapped = function (projectId, selectedHistoryIndex) {
        const result = original.apply(this, arguments);
        if (!wrapping) setTimeout(() => movePanelToHost('sprint1092ComparisonPanel', 'analyticsComparisonHost') || removeEmptyOperationalPanels(), 40);
        return result;
      };
      wrapped.__analyticsWrapped = true;
      wrapped.__original = original;
      comparisonApi.render = wrapped;
    }

    const trendApi = window.FireSTrends1093;
    if (trendApi && typeof trendApi.render === 'function' && !trendApi.render.__analyticsWrapped) {
      const original = trendApi.render;
      const wrapped = function (projectId) {
        const result = original.apply(this, arguments);
        if (!wrapping) setTimeout(() => movePanelToHost('sprint1093TrendPanel', 'analyticsTrendHost') || removeEmptyOperationalPanels(), 40);
        return result;
      };
      wrapped.__analyticsWrapped = true;
      wrapped.__original = original;
      trendApi.render = wrapped;
    }
  }

  function bindAnalyticsButtons() {
    ['analyticsBtn', 'analyticsMenuBtn', 'refreshAnalyticsBtn'].forEach(id => {
      const button = document.getElementById(id);
      if (!button || button.dataset.analyticsConsolidationBound === 'true') return;
      button.dataset.analyticsConsolidationBound = 'true';
      button.addEventListener('click', () => {
        setTimeout(renderConsolidatedAnalytics, 120);
        setTimeout(renderConsolidatedAnalytics, 420);
      });
    });
  }

  function wrapOpenProject() {
    if (typeof window.openProject !== 'function' || window.openProject.__analyticsConsolidationWrapped) return;
    const original = window.openProject;
    const wrapped = function () {
      const result = original.apply(this, arguments);
      setTimeout(() => {
        removeEmptyOperationalPanels();
        if (document.getElementById('analyticsSection')?.style.display !== 'none') renderConsolidatedAnalytics();
      }, 800);
      return result;
    };
    wrapped.__analyticsConsolidationWrapped = true;
    window.openProject = wrapped;
  }

  function addStyles() {
    if (document.getElementById('s1111AnalyticsConsolidationStyles')) return;
    const style = document.createElement('style');
    style.id = 's1111AnalyticsConsolidationStyles';
    style.textContent = `
      #projectFormSection > #sprint109HistoryPanel,
      #projectFormSection > #sprint1092ComparisonPanel,
      #projectFormSection > #sprint1093TrendPanel,
      #inspectionQuickActions + #sprint109HistoryPanel,
      #inspectionQuickActions + #sprint1092ComparisonPanel,
      #inspectionQuickActions + #sprint1093TrendPanel {
        display: none !important;
      }
      #analyticsSection #sprint109HistoryPanel,
      #analyticsSection #sprint1092ComparisonPanel,
      #analyticsSection #sprint1093TrendPanel {
        display: block !important;
      }
      .analytics-consolidated-sections {
        margin-top: 18px;
        display: grid;
        gap: 16px;
      }
      .analytics-subnav {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        padding: 10px;
        border: 1px solid rgba(183, 28, 28, 0.14);
        border-radius: 14px;
        background: #fff;
        position: sticky;
        top: 6px;
        z-index: 3;
      }
      .analytics-subnav a {
        text-decoration: none;
        border: 1px solid rgba(183, 28, 28, 0.18);
        border-radius: 999px;
        padding: 7px 12px;
        color: #7f1515;
        font-weight: 700;
        background: #fff7f7;
      }
      .analytics-management-panel {
        scroll-margin-top: 90px;
      }
      .analytics-panel-heading {
        display: flex;
        justify-content: space-between;
        gap: 12px;
        align-items: flex-start;
        margin-bottom: 12px;
      }
      .analytics-panel-heading h3 { margin: 0 0 4px; }
      .analytics-panel-heading p { margin: 0; color: #666; }
      .analytics-module-host > .analytics-contained-module {
        margin: 0 !important;
        box-shadow: none !important;
      }
      .analytics-anchor { display:block; scroll-margin-top:90px; }
    `;
    document.head.appendChild(style);
  }

  function install() {
    if (installed) return;
    installed = true;
    addStyles();
    wrapOpenProject();
    bindAnalyticsButtons();

    const originalRender = window.fireSRenderAnalytics;
    if (typeof originalRender === 'function' && !originalRender.__analyticsConsolidationWrapped) {
      const wrapped = function () {
        const result = originalRender.apply(this, arguments);
        setTimeout(renderConsolidatedAnalytics, 80);
        return result;
      };
      wrapped.__analyticsConsolidationWrapped = true;
      window.fireSRenderAnalytics = wrapped;
    }

    setInterval(() => {
      wrapModuleRenderers();
      bindAnalyticsButtons();
      removeEmptyOperationalPanels();
    }, 1200);

    setTimeout(() => {
      wrapModuleRenderers();
      removeEmptyOperationalPanels();
    }, 700);

    console.log('Fire-S Sprint 111.1 installed:', VERSION);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => setTimeout(install, 500));
  } else {
    setTimeout(install, 500);
  }

  window.FireSAnalyticsConsolidation1111 = {
    version: VERSION,
    render: renderConsolidatedAnalytics
  };
})();
