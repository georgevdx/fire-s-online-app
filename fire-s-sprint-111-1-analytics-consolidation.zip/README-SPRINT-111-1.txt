Fire-S Sprint 111.1 - Analytics Consolidation

Purpose:
- Move Inspection History, Inspection Comparison and Trend Analytics into the dedicated Analytics workspace.
- Keep operational inspection pages clean and focused.
- Prevent management/statistical panels from occupying space on normal inspection pages.

Notes:
- Analytics now contains Executive Overview plus the consolidated management sections.
- Existing History, Comparison and Trend modules are reused; this sprint relocates their output rather than duplicating logic.
- The Action Register and inspection workflow are not changed.
